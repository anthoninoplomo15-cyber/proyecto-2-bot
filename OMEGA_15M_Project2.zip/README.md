# OMEGA 15M — Project 2

This is the first conversion of Project 2 into a six-agent trading desk.

## What it does

- 14 crypto assets
- 15-minute decision cycle
- SPOTTER / PRIOR / EDGE / KELLY / TAKER / CLOSER agents
- $1 paper position
- +$0.05 paper target
- Paper P&L, win/loss and win rate
- Live public BTC/USD reference from Binance when available
- Mobile-friendly dashboard

## IMPORTANT

This version is PAPER ONLY. It does NOT place orders on Kalshi and the simulated results are not evidence that the strategy is profitable.

## Deploy

### Render / Railway / other Python host

Install:
```bash
pip install -r requirements.txt
```

Run:
```bash
python app.py
```

The Procfile is included for hosts that use Gunicorn.

## Next phase

After confirming the dashboard works, connect it to Kalshi DEMO first. Kalshi currently provides separate demo and production environments. The official API documentation recommends the demo environment for testing, and authentication uses an API key plus RSA-PSS signing.

Do not put a private Kalshi key in the frontend or commit it to GitHub.
