import os, time, math, random, threading
from datetime import datetime, timezone

from flask import Flask, jsonify, render_template
import requests

app = Flask(__name__)

# ============================================================
# PROJECT 2 -> OMEGA 15M
# Paper-trading version.
# It does NOT place real Kalshi orders.
# ============================================================

ASSETS = [
    "BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "AVAX",
    "LINK", "DOT", "LTC", "BCH", "TRX", "TON", "SHIB"
]

STARTING_BANKROLL = 100.00
BET_SIZE = 1.00
TARGET_GAIN = 0.05

state = {
    "bankroll": STARTING_BANKROLL,
    "realized_pnl": 0.0,
    "wins": 0,
    "losses": 0,
    "trades": [],
    "last_update": None,
    "cycle": None,
}

lock = threading.Lock()


def next_15m_epoch():
    now = int(time.time())
    return ((now // 900) + 1) * 900


def seconds_to_next():
    return max(0, next_15m_epoch() - int(time.time()))


def format_countdown(sec):
    m, s = divmod(int(sec), 60)
    return f"{m:02d}:{s:02d}"


def get_btc_price():
    """Public Binance spot price. If unavailable, return None."""
    try:
        r = requests.get(
            "https://api.binance.com/api/v3/ticker/price",
            params={"symbol": "BTCUSDT"},
            timeout=3,
        )
        r.raise_for_status()
        return float(r.json()["price"])
    except Exception:
        return None


def agent(asset, seed=None):
    """
    Six-agent paper signal.
    This is intentionally a transparent prototype:
    - SPOTTER: momentum
    - PRIOR: market/context prior
    - EDGE: agreement/edge
    - KELLY: position sizing score
    - TAKER: entry decision
    - CLOSER: exit/target decision
    """
    rnd = random.Random(seed or f"{asset}-{int(time.time()/15)}")

    spotter = rnd.uniform(-1, 1)
    prior = rnd.uniform(-1, 1)

    # Make EDGE depend partly on the first two agents.
    edge = max(-1, min(1, 0.55 * spotter + 0.45 * prior + rnd.uniform(-0.25, 0.25)))

    # Kelly-style score is a sizing/confidence metric, not financial advice.
    confidence = max(0.0, min(1.0, 0.50 + 0.30 * abs(edge) + rnd.uniform(-0.08, 0.08)))

    direction = "UP" if edge >= 0 else "DOWN"
    taker = confidence >= 0.62 and abs(edge) >= 0.20

    # Closer target is +5 cents in the paper model.
    closer = TARGET_GAIN

    return {
        "asset": asset,
        "spotter": round(spotter, 3),
        "prior": round(prior, 3),
        "edge": round(edge, 3),
        "confidence": round(confidence * 100, 1),
        "direction": direction,
        "taker": taker,
        "closer_target": closer,
    }


def build_cycle():
    btc = get_btc_price()
    signals = [agent(a) for a in ASSETS]

    # Highest-confidence signal first.
    signals.sort(key=lambda x: x["confidence"], reverse=True)

    return {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "btc_price": btc,
        "signals": signals,
        "countdown": format_countdown(seconds_to_next()),
    }


def paper_trade_top_signal(cycle):
    """
    Project 2 rule:
    $1 paper position when the top signal is strong enough.
    Target: +$0.05 on the $1 position.
    This is NOT a claim of profitability.
    """
    top = cycle["signals"][0]
    if not top["taker"]:
        return None

    with lock:
        if state["bankroll"] < BET_SIZE:
            return None

        # Simulate a result. In the real system this would be replaced
        # with actual Kalshi fill/settlement data.
        win_probability = top["confidence"] / 100.0
        win = random.random() < win_probability

        if win:
            pnl = TARGET_GAIN
            state["wins"] += 1
        else:
            # Paper loss assumes the whole $1 stake is lost.
            pnl = -BET_SIZE
            state["losses"] += 1

        state["realized_pnl"] += pnl
        state["bankroll"] += pnl

        trade = {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "asset": top["asset"],
            "direction": top["direction"],
            "confidence": top["confidence"],
            "pnl": round(pnl, 2),
            "result": "WIN" if win else "LOSS",
        }
        state["trades"].insert(0, trade)
        state["trades"] = state["trades"][:50]
        return trade


def worker():
    last_cycle = None
    while True:
        try:
            cycle_key = next_15m_epoch()

            # Build once per 15-minute window.
            if cycle_key != last_cycle:
                cycle = build_cycle()
                trade = paper_trade_top_signal(cycle)
                cycle["paper_trade"] = trade

                with lock:
                    state["cycle"] = cycle
                    state["last_update"] = datetime.now(timezone.utc).isoformat()

                last_cycle = cycle_key

            time.sleep(2)
        except Exception as e:
            with lock:
                state["last_update"] = f"error: {e}"
            time.sleep(5)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/status")
def status():
    with lock:
        cycle = state["cycle"] or build_cycle()
        data = {
            "mode": "PAPER",
            "assets": len(ASSETS),
            "bet_size": BET_SIZE,
            "target_gain": TARGET_GAIN,
            "bankroll": round(state["bankroll"], 2),
            "realized_pnl": round(state["realized_pnl"], 2),
            "wins": state["wins"],
            "losses": state["losses"],
            "win_rate": round(
                100 * state["wins"] / max(1, state["wins"] + state["losses"]), 1
            ),
            "countdown": format_countdown(seconds_to_next()),
            "cycle": cycle,
            "trades": state["trades"],
        }
        return jsonify(data)


if __name__ == "__main__":
    # Starts a background worker for the 15-minute paper engine.
    t = threading.Thread(target=worker, daemon=True)
    t.start()

    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
